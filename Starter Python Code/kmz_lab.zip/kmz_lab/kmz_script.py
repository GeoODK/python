#######################################
# Jon Nordling 
# University of Maryland
# Graduate Research Assistant 
# 08/10/2012
#######################################
#######################################
# This is a python program that converts a text file with lat, lng cordinatons into a 
# Google earth/map format kml/kmz. The program uses a 3rd party module called simpleKml
# Download the folder to test the program. Must install simplekml first
# For Python 2.6 or higher
#######################################
# Sets the imports needed for the program

import os
import sys
import simplekml

#Setting the Global variables
# Loc = the directory where the text files are located
# files = the list of files in that directory 

loc = './'      # current Directory 
files = ['NPP_VIIRS_20120611_AF.txt','NPP_VIIRS_20120618_AF.txt']

# The following function is the main function that will be the first
# function run when the program is launched

def main():
	# loops through each of the files
        for i in files:
                kml = simplekml.Kml()
                in_file = open(i)
                file_lines = in_file.readlines()
                num_lines = len(file_lines)
                for j in range(1, num_lines):
                        line = file_lines[j].strip()		# create an array of all the values in the line
                        lng = line[23:33]                       # create var for lng
                        lat = line[34:]				# Locateds and defines the lat
                        pnt = kml.newpoint(coords=[(lng, lat)])         #create the point
                        pnt.style.iconstyle.icon.href = 'fireicon.png'  #provide an icon for the point (not needed)
                        pnt.style.iconstyle.scale = 1                   # give scale (not needed)
                kml.savekmz(i[0:21]+'.kmz')             # create as a kmz
                in_file.close()                         # close file

if __name__ == '__main__':
    main()








